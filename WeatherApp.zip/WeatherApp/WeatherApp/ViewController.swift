import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    let locationManager = CLLocationManager()
    let weatherViewModel = WeatherViewModel()
    
    // Define UI elements
      let cityTextField: UITextField = {
          let textField = UITextField()
          textField.placeholder = "Enter city"
          textField.borderStyle = .roundedRect
          textField.translatesAutoresizingMaskIntoConstraints = false
          return textField
      }()
      
      let getWeatherButton: UIButton = {
          let button = UIButton(type: .system)
          button.setTitle("Get Weather", for: .normal)
          button.addTarget(self, action: #selector(getWeatherTapped), for: .touchUpInside)
          button.translatesAutoresizingMaskIntoConstraints = false
          return button
      }()
      
      let weatherLabel: UILabel = {
          let label = UILabel()
          label.text = "Weather Information"
          label.textAlignment = .center
          label.translatesAutoresizingMaskIntoConstraints = false
          return label
      }()
      
      let weatherImageView: UIImageView = {
          let imageView = UIImageView()
          imageView.contentMode = .scaleAspectFit
          imageView.translatesAutoresizingMaskIntoConstraints = false
          return imageView
      }()
    
    let lastCityKey = "lastCity"

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
                
                // Add subviews to the main view
                view.addSubview(cityTextField)
                view.addSubview(getWeatherButton)
                view.addSubview(weatherLabel)
                view.addSubview(weatherImageView)
                
                // Set up constraints
                setupConstraints()
        loadLastCity()
        requestLocationPermission()
        bindViewModel()
    }
    
    private func setupConstraints() {
           // Constraints for cityTextField
           NSLayoutConstraint.activate([
               cityTextField.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
               cityTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
               cityTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
               cityTextField.heightAnchor.constraint(equalToConstant: 40)
           ])
           
           // Constraints for getWeatherButton
           NSLayoutConstraint.activate([
               getWeatherButton.topAnchor.constraint(equalTo: cityTextField.bottomAnchor, constant: 20),
               getWeatherButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               getWeatherButton.heightAnchor.constraint(equalToConstant: 44)
           ])
           
           // Constraints for weatherLabel
           NSLayoutConstraint.activate([
               weatherLabel.topAnchor.constraint(equalTo: getWeatherButton.bottomAnchor, constant: 20),
               weatherLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor),
               weatherLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
               weatherLabel.heightAnchor.constraint(equalToConstant: 50)
           ])
           
           // Constraints for weatherImageView
           NSLayoutConstraint.activate([
               weatherImageView.topAnchor.constraint(equalTo: weatherLabel.bottomAnchor, constant: 20),
               weatherImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               weatherImageView.widthAnchor.constraint(equalToConstant: 100),
               weatherImageView.heightAnchor.constraint(equalToConstant: 100)
           ])
       }
    
    @objc private func getWeatherTapped() {
        guard let city = cityTextField.text, !city.isEmpty else { return }
        weatherViewModel.fetchWeather(for: city)
        cacheLastCity(city: city)
    }
    
    private func bindViewModel() {
        weatherViewModel.updateWeatherLabel = { [weak self] in
            self?.updateUI()
        }
    }
    
    private func updateUI() {
        weatherLabel.text = weatherViewModel.getWeatherDescription()
        if let iconURL = weatherViewModel.getWeatherIconURL() {
            loadWeatherIcon(from: iconURL)
        }
    }

    func cacheLastCity(city: String) {
        UserDefaults.standard.setValue(city, forKey: lastCityKey)
    }

    func loadLastCity() {
        if let lastCity = UserDefaults.standard.string(forKey: lastCityKey) {
            cityTextField.text = lastCity
            weatherViewModel.fetchWeather(for: lastCity)
        }
    }
    
    func requestLocationPermission() {
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first {
            weatherViewModel.fetchWeather(for: "\(location.coordinate.latitude),\(location.coordinate.longitude)")
            locationManager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Failed to find user's location: \(error.localizedDescription)")
    }
    
    private func loadWeatherIcon(from url: URL) {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data, let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.weatherImageView.image = image
                }
            }
        }
        task.resume()
    }
}


