//
//  WeatherViewModel.swift
//  WeatherApp
//
//  Created by Sadiq on 9/19/24.
//

import Foundation

class WeatherViewModel {
    private let apiKey = "6639e4800a932e56c6037d6971313b9b"
    
    var weatherData: WeatherResponse? {
        didSet {
            updateWeatherLabel?()
        }
    }
    
    var updateWeatherLabel: (() -> Void)?
    
    func fetchWeather(for city: String) {
        let urlString = "https://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=\(apiKey)&units=metric"
        
        guard let url = URL(string: urlString) else { return }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self?.weatherData = nil
                }
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else { return }
            
            do {
                let weatherData = try JSONDecoder().decode(WeatherResponse.self, from: data)
                DispatchQueue.main.async {
                    self?.weatherData = weatherData
                }
            } catch {
                DispatchQueue.main.async {
                    self?.weatherData = nil
                }
                print("Error decoding data: \(error.localizedDescription)")
            }
        }
        task.resume()
    }
    
    func getWeatherDescription() -> String {
        guard let weatherData = weatherData else { return "Please enter a valid location" }
        let cityName = weatherData.name
        let temperature = weatherData.main.temp
        let description = weatherData.weather.first?.description ?? ""
        
        return "Weather in \(cityName): \(temperature)°C, \(description)"
    }
    
    func getWeatherIconURL() -> URL? {
        guard let iconCode = weatherData?.weather.first?.icon else { return nil }
        let iconUrlString = "http://openweathermap.org/img/wn/\(iconCode)@2x.png"
        return URL(string: iconUrlString)
    }
}
